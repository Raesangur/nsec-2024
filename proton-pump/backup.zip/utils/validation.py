def is_true(value):
  return value.lower() == 'true'